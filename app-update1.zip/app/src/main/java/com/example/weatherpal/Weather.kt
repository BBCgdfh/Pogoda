package com.example.weatherpal

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.net.URL
import java.util.Calendar
import kotlin.coroutines.resume

enum class Sky { CLEAR, NIGHT, CLOUDY, RAIN, SNOW, STORM, WINDY, NEWYEAR }

data class Weather(val temp: Int, val wind: Int, val sky: Sky)

private fun newYearSeason(): Boolean {
    val c = Calendar.getInstance()
    val m = c.get(Calendar.MONTH)
    val d = c.get(Calendar.DAY_OF_MONTH)
    return (m == Calendar.DECEMBER && d >= 15) || (m == Calendar.JANUARY && d <= 10)
}

/** Open-Meteo: бесплатно и без ключа. */
suspend fun loadWeather(lat: Double, lon: Double): Weather = withContext(Dispatchers.IO) {
    val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
        "&current=temperature_2m,weather_code,wind_speed_10m,is_day"
    val conn = URL(url).openConnection()
    conn.connectTimeout = 8000
    conn.readTimeout = 8000
    val text = conn.getInputStream().bufferedReader().use { it.readText() }
    val cur = JSONObject(text).getJSONObject("current")
    val code = cur.getInt("weather_code")
    val wind = cur.getDouble("wind_speed_10m") // км/ч
    val night = cur.getInt("is_day") == 0
    var sky: Sky = when {
        code >= 95 -> Sky.STORM
        code in 71..77 || code == 85 || code == 86 -> Sky.SNOW
        code in 51..67 || code in 80..82 -> Sky.RAIN
        wind > 35 -> Sky.WINDY
        code <= 1 -> if (night) Sky.NIGHT else Sky.CLEAR
        else -> Sky.CLOUDY
    }
    if (newYearSeason() && sky != Sky.RAIN && sky != Sky.STORM) sky = Sky.NEWYEAR
    Weather(Math.round(cur.getDouble("temperature_2m")).toInt(), Math.round(wind).toInt(), sky)
}

/** Координаты по сети (приблизительно). Нужно разрешение ACCESS_COARSE_LOCATION. */
@SuppressLint("MissingPermission")
suspend fun getLocation(ctx: Context): Pair<Double, Double>? = withContext(Dispatchers.Main) {
    try {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val providers = lm.getProviders(true)
        var best: Location? = null
        for (p in providers) {
            val l = lm.getLastKnownLocation(p)
            val b = best
            if (l != null && (b == null || l.time > b.time)) best = l
        }
        val found = best
        if (found != null) {
            return@withContext Pair(found.latitude, found.longitude)
        }
        val provider = when {
            providers.contains(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
            providers.contains(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
            else -> return@withContext null
        }
        withTimeoutOrNull(10_000L) {
            suspendCancellableCoroutine<Pair<Double, Double>?> { cont ->
                val listener = object : LocationListener {
                    override fun onLocationChanged(location: Location) {
                        lm.removeUpdates(this)
                        if (cont.isActive) cont.resume(Pair(location.latitude, location.longitude))
                    }
                    @Deprecated("old api")
                    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                    override fun onProviderEnabled(provider: String) {}
                    override fun onProviderDisabled(provider: String) {}
                }
                lm.requestLocationUpdates(provider, 0L, 0f, listener, Looper.getMainLooper())
                cont.invokeOnCancellation { lm.removeUpdates(listener) }
            }
        }
    } catch (e: Exception) {
        null
    }
}

fun skyTitle(s: Sky): String = when (s) {
    Sky.CLEAR -> "Солнечно"
    Sky.NIGHT -> "Ясная ночь"
    Sky.CLOUDY -> "Облачно"
    Sky.RAIN -> "Дождь"
    Sky.SNOW -> "Идёт снег"
    Sky.STORM -> "Гроза"
    Sky.WINDY -> "Ветрено"
    Sky.NEWYEAR -> "Новый год"
}

// Позже эти фразы можно генерировать ИИ через ваш прокси-сервер
fun phrases(s: Sky): List<String> = when (s) {
    Sky.CLEAR -> listOf(
        "Ух, солнце! Очки надел, пойду загорать!",
        "Жарко! Кто-нибудь, дайте мороженое!",
        "Я не толстею, я просто загораю со всех сторон."
    )
    Sky.NIGHT -> listOf(
        "Zzz... ещё пять минуточек...",
        "Тсс! Звёзды работают.",
        "Я не сплю. Я просто думаю с закрытыми глазами."
    )
    Sky.CLOUDY -> listOf(
        "Облачка плывут... я считаю их.",
        "Серо, но внутри у меня звёздочка!",
        "Облака — мои дальние родственники."
    )
    Sky.RAIN -> listOf(
        "Кап-кап! Где мой зонтик?!",
        "Я не промок, я освежился!",
        "Лужи — это мои океаны."
    )
    Sky.SNOW -> listOf(
        "СНЕГ! Я такого ещё не видел! Играем в снежки?",
        "Холодно, но звёздочка греет!",
        "Лепим снеговика?"
    )
    Sky.STORM -> listOf(
        "Бабах! Я не боюсь... почти.",
        "Это просто небо чихнуло!",
        "Спрячьте меня под одеяло!"
    )
    Sky.WINDY -> listOf(
        "Ууу, держите меня, а то улечу!",
        "Моя причёска! Хотя у меня её нет.",
        "Ветер, ты чего такой шумный?"
    )
    Sky.NEWYEAR -> listOf(
        "С Новым годом! Я нарядил ёлку!",
        "Загадал желание. Тсс, не скажу!",
        "Где мои подарки?!"
    )
}
