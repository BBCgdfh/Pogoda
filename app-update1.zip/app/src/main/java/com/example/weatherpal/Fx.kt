package com.example.weatherpal

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

@Stable
class Clock {
    var t by mutableFloatStateOf(0f)
}

/** Время в секундах, обновляется каждый кадр. Читать только внутри Canvas. */
@Composable
fun rememberClock(): Clock {
    val c = remember { Clock() }
    LaunchedEffect(c) {
        var t0 = -1L
        while (true) {
            withFrameNanos { n ->
                if (t0 < 0L) t0 = n
                c.t = (n - t0) / 1_000_000_000f
            }
        }
    }
    return c
}

private class Cloud(val x: Float, val y: Float, val s: Float, val v: Float)

private class P(var x: Float, var y: Float, val v: Float, val s: Float, val ph: Float)

/** Фон: солнце, луна, звёзды, облака, сугробы. */
@Composable
fun SkyScene(sky: Sky) {
    val clock = rememberClock()
    val clouds = remember {
        List(5) {
            Cloud(
                Random.nextFloat(),
                0.05f + Random.nextFloat() * 0.3f,
                0.6f + Random.nextFloat() * 0.8f,
                0.01f + Random.nextFloat() * 0.02f
            )
        }
    }
    val stars = remember {
        List(50) {
            floatArrayOf(Random.nextFloat(), Random.nextFloat() * 0.7f, Random.nextFloat() * 6.28f, 1.5f + Random.nextFloat() * 2.5f)
        }
    }
    Canvas(Modifier.fillMaxSize()) {
        val t = clock.t
        when (sky) {
            Sky.CLEAR -> {
                drawSun(t)
                drawClouds(clouds.take(2), t, Color.White)
            }
            Sky.NIGHT -> {
                drawStars(stars, t)
                drawMoon()
            }
            Sky.CLOUDY -> drawClouds(clouds, t, Color(0xFFCFD8DC))
            Sky.RAIN -> drawClouds(clouds, t, Color(0xFF455A64))
            Sky.STORM -> drawClouds(clouds, t, Color(0xFF1F2933))
            Sky.WINDY -> drawClouds(clouds.take(3), t, Color(0xFFE0F7FA))
            Sky.SNOW -> drawGround()
            Sky.NEWYEAR -> {
                drawStars(stars, t)
                drawGround()
            }
        }
    }
}

private fun DrawScope.drawSun(t: Float) {
    val c = Offset(size.width * 0.8f, size.height * 0.13f)
    val r = size.width * 0.075f
    drawCircle(
        Brush.radialGradient(listOf(Color(0x66FFF59D), Color(0x00FFF59D)), center = c, radius = r * 3.2f),
        radius = r * 3.2f,
        center = c
    )
    val step = 2f * PI.toFloat() / 12f
    for (i in 0 until 12) {
        val a = t * 0.4f + i * step
        val s = Offset(c.x + cos(a) * r * 1.4f, c.y + sin(a) * r * 1.4f)
        val e = Offset(c.x + cos(a) * r * 1.9f, c.y + sin(a) * r * 1.9f)
        drawLine(Color(0xFFFFE082), s, e, strokeWidth = r * 0.14f, cap = StrokeCap.Round)
    }
    drawCircle(Color(0xFFFFEB3B), r, c)
}

private fun DrawScope.drawMoon() {
    val c = Offset(size.width * 0.78f, size.height * 0.12f)
    val r = size.width * 0.07f
    drawCircle(
        Brush.radialGradient(listOf(Color(0x55FFF8E1), Color(0x00FFF8E1)), center = c, radius = r * 3f),
        radius = r * 3f,
        center = c
    )
    drawCircle(Color(0xFFFFF8E1), r, c)
    drawCircle(Color(0x22000000), r * 0.2f, Offset(c.x - r * 0.3f, c.y - r * 0.2f))
    drawCircle(Color(0x22000000), r * 0.14f, Offset(c.x + r * 0.35f, c.y + r * 0.3f))
    drawCircle(Color(0x22000000), r * 0.1f, Offset(c.x + r * 0.2f, c.y - r * 0.45f))
}

private fun DrawScope.drawStars(stars: List<FloatArray>, t: Float) {
    for (s in stars) {
        val a = 0.4f + 0.6f * (0.5f + 0.5f * sin(t * 2f + s[2]))
        drawCircle(Color.White.copy(alpha = a), s[3] * density * 0.6f, Offset(s[0] * size.width, s[1] * size.height))
    }
}

private fun DrawScope.drawClouds(clouds: List<Cloud>, t: Float, color: Color) {
    for (c in clouds) {
        val u = size.width * 0.05f * c.s
        val cx = ((c.x + t * c.v) % 1.4f - 0.2f) * size.width
        val cy = c.y * size.height
        drawCircle(color, u, Offset(cx, cy))
        drawCircle(color, u * 1.4f, Offset(cx + u * 1.2f, cy - u * 0.4f))
        drawCircle(color, u, Offset(cx + u * 2.4f, cy))
        drawRoundRect(color, Offset(cx - u * 0.6f, cy), Size(u * 4.0f, u * 0.9f), CornerRadius(u * 0.45f))
    }
}

private fun DrawScope.drawGround() {
    val w = size.width
    val h = size.height
    val gy = h * 0.87f
    val p = Path()
    p.moveTo(0f, h)
    p.lineTo(0f, gy)
    var x = 0f
    val step = w / 40f
    while (x <= w) {
        p.lineTo(x, gy + sin(x / w * 12.5f) * h * 0.012f)
        x += step
    }
    p.lineTo(w, h)
    p.close()
    drawPath(p, Brush.verticalGradient(listOf(Color(0xFFF5F8FF), Color(0xFFDCE6FA)), startY = gy, endY = h))
}

/** Осадки и ветер: снег, дождь, порывы. В грозу — вспышки и гром. */
@Composable
fun FallingFx(sky: Sky) {
    val mode = when (sky) {
        Sky.SNOW, Sky.NEWYEAR -> 1
        Sky.RAIN, Sky.STORM -> 2
        Sky.WINDY -> 3
        else -> 0
    }
    if (mode == 0) return

    val clock = rememberClock()
    val count = when (mode) {
        1 -> 90
        2 -> 130
        else -> 22
    }
    val parts = remember(mode) {
        List(count) {
            P(
                Random.nextFloat(),
                Random.nextFloat(),
                when (mode) {
                    1 -> 0.07f + Random.nextFloat() * 0.13f
                    2 -> 0.9f + Random.nextFloat() * 0.6f
                    else -> 0.5f + Random.nextFloat() * 0.8f
                },
                if (mode == 1) 2f + Random.nextFloat() * 4.5f else 1f,
                Random.nextFloat() * 6.28f
            )
        }
    }
    val last = remember(mode) { floatArrayOf(0f) }
    val flash = remember(mode) { floatArrayOf(5f, 0f) }

    Canvas(Modifier.fillMaxSize()) {
        val t = clock.t
        val dt = (t - last[0]).coerceIn(0f, 0.1f)
        last[0] = t
        val w = size.width
        val h = size.height
        for (p in parts) {
            when (mode) {
                1 -> {
                    p.y += p.v * dt
                    if (p.y > 1f) {
                        p.y = -0.02f
                        p.x = Random.nextFloat()
                    }
                    val x = (p.x + sin(t * 0.8f + p.ph) * 0.02f) * w
                    drawCircle(Color.White, p.s * density, Offset(x, p.y * h))
                }
                2 -> {
                    p.y += p.v * dt
                    if (p.y > 1.02f) {
                        p.y = -0.05f
                        p.x = Random.nextFloat()
                    }
                    val x = p.x * w
                    val y = p.y * h
                    drawLine(
                        Color(0xAA9EC9FF), Offset(x, y), Offset(x - 0.01f * w, y + 0.04f * h),
                        strokeWidth = 1.5f * density
                    )
                }
                else -> {
                    p.x += p.v * dt * 0.9f
                    if (p.x > 1.1f) {
                        p.x = -0.2f
                        p.y = Random.nextFloat()
                    }
                    val y = p.y * h + sin(t * 2f + p.ph) * 0.01f * h
                    drawLine(
                        Color(0x88FFFFFF), Offset(p.x * w, y), Offset(p.x * w - 0.12f * w, y),
                        strokeWidth = 2f * density, cap = StrokeCap.Round
                    )
                }
            }
        }
        if (sky == Sky.STORM) {
            if (t > flash[0]) {
                flash[1] = t + 0.22f
                flash[0] = t + 4f + Random.nextFloat() * 6f
                Sfx.play("thunder")
            }
            if (t < flash[1]) drawRect(Color(0x66FFFFFF))
        }
    }
}
