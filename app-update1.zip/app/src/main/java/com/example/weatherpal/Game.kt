package com.example.weatherpal

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.random.Random

/** Настройки мини-игры для каждой погоды. */
class GameCfg(
    val key: String,
    val title: String,
    val hint: String,
    val catchMode: Boolean,   // true: ловим корзиной, false: сбиваем тапом
    val good: List<String?>,  // null = снежок
    val bad: List<String>,
    val vMin: Float,
    val vMax: Float,
    val every: Float,
    val sway: Float
)

fun gameFor(s: Sky): GameCfg = when (s) {
    Sky.SNOW -> GameCfg("snow", "Снежки", "Сбивай снежки тапом. Пингвинов не трогай!", false, listOf(null), listOf("🐧"), 0.25f, 0.5f, 0.8f, 0f)
    Sky.RAIN -> GameCfg("rain", "Лови капли", "Води ведёрко пальцем. Молнии не лови!", true, listOf("💧"), listOf("⚡"), 0.25f, 0.5f, 0.7f, 0f)
    Sky.CLEAR -> GameCfg("clear", "Мороженое", "Лови мороженое. Огонь не лови!", true, listOf("🍦"), listOf("🔥"), 0.25f, 0.5f, 0.8f, 0f)
    Sky.NIGHT -> GameCfg("night", "Звездопад", "Лови звёзды. Пришельцев не лови!", true, listOf("⭐"), listOf("👽"), 0.25f, 0.45f, 0.8f, 0f)
    Sky.CLOUDY -> GameCfg("cloudy", "Шарики", "Лови шарики. Птиц не лови!", true, listOf("🎈"), listOf("🐦"), 0.22f, 0.42f, 0.9f, 0.02f)
    Sky.STORM -> GameCfg("storm", "Молнии", "Тапай молнии. Радугу не трогай!", false, listOf("⚡"), listOf("🌈"), 0.3f, 0.55f, 0.7f, 0f)
    Sky.WINDY -> GameCfg("windy", "Улетает!", "Лови улетающие вещи тапом. Кактус не трогай!", false, listOf("🎈", "🍂"), listOf("🌵"), 0.25f, 0.45f, 0.8f, 0.07f)
    Sky.NEWYEAR -> GameCfg("newyear", "Подарки", "Лови подарки. Огонь не лови!", true, listOf("🎁", "⭐"), listOf("🔥"), 0.25f, 0.5f, 0.75f, 0f)
}

private class Item(
    val good: Boolean,
    val glyph: String?,
    val x: Float,
    var y: Float,
    val v: Float,
    val ph: Float
)

@Composable
fun GameScreen(sky: Sky, onClose: () -> Unit) {
    val cfg = remember(sky) { gameFor(sky) }
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("scores", Context.MODE_PRIVATE) }
    var best by remember { mutableIntStateOf(prefs.getInt("best_" + cfg.key, 0)) }
    var score by remember { mutableIntStateOf(0) }
    var lives by remember { mutableIntStateOf(5) }
    var round by remember { mutableIntStateOf(0) }
    var tick by remember { mutableLongStateOf(0L) }
    var mood by remember { mutableStateOf(Mood.IDLE) }
    var moodKey by remember { mutableIntStateOf(0) }
    var bx by remember { mutableFloatStateOf(0.5f) }
    var newRecord by remember { mutableStateOf(false) }
    val items = remember { mutableListOf<Item>() }
    val gt = remember { floatArrayOf(0f) }

    fun react(m: Mood) {
        mood = m
        moodKey++
    }

    fun ex(i: Item): Float = (i.x + cfg.sway * sin(gt[0] * 2f + i.ph)).coerceIn(0.06f, 0.94f)

    LaunchedEffect(moodKey) {
        if (moodKey > 0) {
            delay(600)
            mood = Mood.IDLE
        }
    }

    LaunchedEffect(lives) {
        if (lives <= 0) {
            if (score > best) {
                best = score
                newRecord = true
                prefs.edit().putInt("best_" + cfg.key, score).apply()
                Sfx.play("yay")
            } else {
                Sfx.play("wobble")
            }
        }
    }

    LaunchedEffect(round) {
        items.clear()
        gt[0] = 0f
        var last = 0L
        var spawn = 0f
        while (true) {
            withFrameNanos { n ->
                val dt = if (last == 0L) 0f else ((n - last) / 1_000_000_000f).coerceAtMost(0.05f)
                last = n
                if (lives > 0) {
                    gt[0] += dt
                    spawn += dt
                    val every = (cfg.every - gt[0] * 0.012f).coerceAtLeast(0.4f)
                    if (spawn > every) {
                        spawn = 0f
                        val bad = cfg.bad.isNotEmpty() && Random.nextFloat() < 0.22f
                        val g: String? = if (bad) cfg.bad.random() else cfg.good.random()
                        val speed = (cfg.vMin + Random.nextFloat() * (cfg.vMax - cfg.vMin)) * (1f + gt[0] * 0.012f)
                        items.add(Item(!bad, g, 0.1f + Random.nextFloat() * 0.8f, 0.1f, speed, Random.nextFloat() * 6.28f))
                    }
                    val iter = items.iterator()
                    while (iter.hasNext()) {
                        val i = iter.next()
                        i.y += i.v * dt
                        val x = ex(i)
                        if (cfg.catchMode && i.y >= 0.88f && abs(x - bx) < 0.16f) {
                            iter.remove()
                            if (i.good) {
                                score++
                                Sfx.play("boop")
                                react(Mood.HAPPY)
                            } else {
                                lives--
                                Sfx.play("sad")
                                react(Mood.SAD)
                            }
                        } else if (i.y > 1.05f) {
                            iter.remove()
                            if (i.good) {
                                lives--
                                Sfx.play("pop")
                                react(Mood.SAD)
                            }
                        }
                    }
                }
                tick = n
            }
        }
    }

    val gesture: Modifier = if (cfg.catchMode) {
        Modifier
            .pointerInput(round) {
                detectTapGestures { o -> bx = (o.x / size.width).coerceIn(0.08f, 0.92f) }
            }
            .pointerInput(round) {
                detectHorizontalDragGestures { change, dx ->
                    change.consume()
                    bx = (bx + dx / size.width).coerceIn(0.08f, 0.92f)
                }
            }
    } else {
        Modifier.pointerInput(round) {
            detectTapGestures { o ->
                if (lives > 0) {
                    val w = size.width.toFloat()
                    val h = size.height.toFloat()
                    val hit = items.lastOrNull { hypot(ex(it) * w - o.x, it.y * h - o.y) < 110f }
                    if (hit != null) {
                        items.remove(hit)
                        if (hit.good) {
                            score++
                            Sfx.play("pop")
                            react(Mood.HAPPY)
                        } else {
                            lives--
                            Sfx.play("sad")
                            react(Mood.SAD)
                        }
                    }
                }
            }
        }
    }

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .background(Color(0xE6101028))
            .then(gesture)
    ) {
        val mw = maxWidth
        val mh = maxHeight
        val frame = tick

        Buddy(
            sky,
            Modifier.align(Alignment.TopCenter).offset(y = 70.dp),
            mood = mood,
            boxSize = 150.dp,
            interactive = false
        )

        for (i in items.toList()) {
            val x = ex(i)
            val g = i.glyph
            if (g == null) {
                Box(
                    Modifier
                        .offset(mw * x - 22.dp, mh * i.y - 22.dp)
                        .size(44.dp)
                        .background(Color.White, CircleShape)
                        .border(2.dp, Color(0xFFB3E5FC), CircleShape)
                )
            } else {
                Text(g, fontSize = 36.sp, modifier = Modifier.offset(mw * x - 22.dp, mh * i.y - 22.dp))
            }
        }

        if (cfg.catchMode) {
            val shape = RoundedCornerShape(0.dp, 0.dp, 26.dp, 26.dp)
            Box(
                Modifier
                    .offset(mw * bx - 42.dp, mh * 0.9f)
                    .size(84.dp, 44.dp)
                    .background(Color(0xFF8D6E63), shape)
                    .border(3.dp, Color(0xFFD7B899), shape)
            )
        }

        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Очки: $score", color = Color.White, fontSize = 22.sp)
                Text("❤️".repeat(lives.coerceAtLeast(0)), fontSize = 18.sp)
                Button(onClick = onClose) { Text("✕") }
            }
            Text(
                "${cfg.title}. ${cfg.hint}  Рекорд: $best",
                color = Color(0xCCFFFFFF), fontSize = 14.sp
            )
        }

        if (lives <= 0) {
            Column(
                Modifier.align(Alignment.Center),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Игра окончена!", color = Color.White, fontSize = 28.sp)
                Spacer(Modifier.height(8.dp))
                Text(
                    if (newRecord) "Очки: $score. Новый рекорд! 🏆" else "Очки: $score",
                    color = Color.White, fontSize = 20.sp, textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(16.dp))
                Button(onClick = {
                    score = 0
                    lives = 5
                    newRecord = false
                    round++
                }) { Text("Ещё раз") }
                Spacer(Modifier.height(8.dp))
                Button(onClick = onClose) { Text("Закрыть") }
            }
        }
    }
}
