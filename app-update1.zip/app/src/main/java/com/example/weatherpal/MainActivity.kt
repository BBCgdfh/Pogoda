package com.example.weatherpal

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

private fun skyColors(s: Sky): List<Color> = when (s) {
    Sky.SNOW, Sky.NEWYEAR -> listOf(Color(0xFF141E5A), Color(0xFF3F51B5))
    Sky.RAIN -> listOf(Color(0xFF2B3A47), Color(0xFF5C7080))
    Sky.STORM -> listOf(Color(0xFF14181F), Color(0xFF3A4452))
    Sky.CLEAR -> listOf(Color(0xFF1E88E5), Color(0xFF81D4FA))
    Sky.NIGHT -> listOf(Color(0xFF050B2E), Color(0xFF1A237E))
    Sky.CLOUDY -> listOf(Color(0xFF546E7A), Color(0xFFB0BEC5))
    Sky.WINDY -> listOf(Color(0xFF4DB6AC), Color(0xFFB2EBF2))
}

private fun enterSound(s: Sky): String = when (s) {
    Sky.SNOW -> "yay"
    Sky.RAIN -> "splat"
    Sky.STORM -> "thunder"
    Sky.WINDY -> "whoosh"
    Sky.CLEAR -> "boop"
    Sky.NIGHT -> "wobble"
    Sky.CLOUDY -> "squeak"
    Sky.NEWYEAR -> "giggle"
}

@Composable
private fun Glass(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier
            .clip(shape)
            .background(Color(0x33FFFFFF))
            .border(1.dp, Color(0x33FFFFFF), shape)
            .padding(14.dp),
        content = content
    )
}

@Composable
fun App() {
    val ctx = LocalContext.current
    var weather by remember { mutableStateOf<Weather?>(null) }
    var forced by remember { mutableStateOf<Sky?>(null) }
    var playing by remember { mutableStateOf(false) }
    var coords by remember { mutableStateOf<Pair<Double, Double>?>(null) }
    var usedGps by remember { mutableStateOf(false) }
    var muted by remember { mutableStateOf(false) }
    var line by remember { mutableStateOf("") }
    var granted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        granted = ok
    }

    LaunchedEffect(Unit) {
        if (!granted) launcher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
    }
    LaunchedEffect(granted) {
        val loc = if (granted) getLocation(ctx) else null
        usedGps = loc != null
        coords = loc ?: Pair(55.75, 37.62) // Москва по умолчанию
    }
    LaunchedEffect(coords) {
        val c = coords
        if (c != null) {
            while (true) {
                try {
                    weather = loadWeather(c.first, c.second)
                } catch (e: Exception) {
                    // нет сети: оставляем прошлую погоду
                }
                delay(15 * 60 * 1000L)
            }
        }
    }
    LaunchedEffect(muted) { Sfx.enabled = !muted }

    val sky = forced ?: weather?.sky ?: Sky.CLEAR
    LaunchedEffect(sky) {
        line = phrases(sky).random()
        Sfx.play(enterSound(sky))
    }
    val best = remember(playing, sky) {
        ctx.getSharedPreferences("scores", Context.MODE_PRIVATE).getInt("best_" + gameFor(sky).key, 0)
    }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(skyColors(sky)))) {
        SkyScene(sky)
        FallingFx(sky)

        Column(
            Modifier.fillMaxSize().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Glass(Modifier.weight(1f)) {
                    Text(
                        weather?.let { "${it.temp}°" } ?: "…",
                        fontSize = 52.sp, color = Color.White
                    )
                    Text(skyTitle(sky), fontSize = 18.sp, color = Color.White)
                    val windText = weather?.let { "Ветер ${it.wind} км/ч" } ?: "Загрузка..."
                    Text(windText, fontSize = 13.sp, color = Color(0xCCFFFFFF))
                    Text(
                        if (usedGps) "📍 по вашему местоположению" else "📍 Москва (по умолчанию)",
                        fontSize = 12.sp, color = Color(0xCCFFFFFF)
                    )
                }
                Glass {
                    Text(
                        if (muted) "🔇" else "🔊", fontSize = 28.sp,
                        modifier = Modifier.clickable { muted = !muted }
                    )
                    Spacer(Modifier.height(10.dp))
                    Text("🏆 $best", fontSize = 18.sp, color = Color.White)
                }
            }

            Spacer(Modifier.weight(1f))
            Buddy(sky, onTap = {
                line = phrases(sky).random()
                Sfx.play(listOf("squeak", "boop", "giggle", "wobble").random())
            })
            Text(
                line,
                color = Color.White, fontSize = 18.sp, textAlign = TextAlign.Center,
                modifier = Modifier
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color(0x33FFFFFF))
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            )
            Spacer(Modifier.weight(1f))

            Button(onClick = { playing = true }) {
                Text("🎮 Играть: ${gameFor(sky).title}")
            }
            Row(Modifier.horizontalScroll(rememberScrollState())) {
                Sky.values().forEach { s ->
                    TextButton(onClick = { forced = s }) {
                        Text(skyTitle(s), color = Color.White, fontSize = 13.sp)
                    }
                }
                TextButton(onClick = { forced = null }) {
                    Text("Авто", color = Color(0xFFFFE082), fontSize = 13.sp)
                }
            }
        }

        if (playing) GameScreen(sky) { playing = false }
    }
}
