package com.example.weatherpal

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

/** Смешные звуки, синтезируются кодом — файлы не нужны. */
object Sfx {
    @Volatile
    var enabled = true

    private const val SR = 22050
    private val active = AtomicInteger(0)
    private val bank: Map<String, ShortArray> by lazy { buildBank() }

    private fun tone(f0: Double, f1: Double, ms: Int, vib: Double = 0.0, vol: Double = 0.45): ShortArray {
        val n = SR * ms / 1000
        val out = ShortArray(n)
        var ph = 0.0
        for (i in 0 until n) {
            val t = i.toDouble() / n
            var f = f0 + (f1 - f0) * t
            if (vib > 0.0) f *= 1.0 + 0.08 * sin(2.0 * PI * vib * i / SR)
            ph += 2.0 * PI * f / SR
            val env = minOf(1.0, t * 20.0) * (1.0 - t)
            out[i] = (sin(ph) * env * vol * Short.MAX_VALUE).toInt().toShort()
        }
        return out
    }

    private fun gap(ms: Int): ShortArray = ShortArray(SR * ms / 1000)

    private fun noise(ms: Int): ShortArray {
        val n = SR * ms / 1000
        val out = ShortArray(n)
        for (i in 0 until n) {
            val t = i.toDouble() / n
            out[i] = ((Random.nextDouble() * 2.0 - 1.0) * (1.0 - t) * 0.25 * Short.MAX_VALUE).toInt().toShort()
        }
        return out
    }

    private fun cat(vararg parts: ShortArray): ShortArray {
        var r = ShortArray(0)
        for (x in parts) r += x
        return r
    }

    private fun buildBank(): Map<String, ShortArray> = mapOf(
        "boop" to tone(320.0, 640.0, 130),
        "pop" to tone(800.0, 250.0, 90),
        "squeak" to tone(1000.0, 1800.0, 100),
        "sad" to tone(520.0, 160.0, 420, vib = 9.0),
        "wobble" to tone(420.0, 520.0, 520, vib = 14.0),
        "giggle" to cat(
            tone(700.0, 1000.0, 60), gap(40), tone(750.0, 1050.0, 60), gap(40),
            tone(800.0, 1100.0, 60), gap(40), tone(850.0, 1200.0, 90)
        ),
        "yay" to cat(tone(400.0, 600.0, 90), tone(600.0, 800.0, 90), tone(800.0, 1200.0, 180)),
        "splat" to cat(noise(60), tone(300.0, 100.0, 120)),
        "whoosh" to noise(350),
        "thunder" to cat(noise(260), tone(90.0, 40.0, 520, vol = 0.7))
    )

    fun play(name: String) {
        if (!enabled || active.get() >= 6) return
        val data = bank[name] ?: return
        active.incrementAndGet()
        Thread {
            try {
                val rate = 0.85 + Random.nextDouble() * 0.5
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(SR)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(data.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
                track.write(data, 0, data.size)
                track.playbackRate = (SR * rate).toInt()
                track.play()
                Thread.sleep((data.size * 1000L / SR / rate).toLong() + 100L)
                track.release()
            } catch (e: Exception) {
                // звук не критичен
            } finally {
                active.decrementAndGet()
            }
        }.start()
    }
}
