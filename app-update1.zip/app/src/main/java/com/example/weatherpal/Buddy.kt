package com.example.weatherpal

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

enum class Mood { IDLE, HAPPY, SAD }

private fun starPath(cx: Float, cy: Float, rOut: Float, rIn: Float, rot: Float): Path {
    val p = Path()
    val n = 10
    for (i in 0 until n * 2) {
        val a = rot + i * PI.toFloat() / n
        val r = if (i % 2 == 0) rOut else rIn
        val x = cx + cos(a) * r
        val y = cy + sin(a) * r
        if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
    }
    p.close()
    return p
}

/**
 * Наш персонаж: тёмное облачко-цветок со светящейся звёздочкой.
 * Тап по нему — он пищит и пружинит.
 */
@Composable
fun Buddy(
    sky: Sky,
    modifier: Modifier = Modifier,
    mood: Mood = Mood.IDLE,
    boxSize: Dp = 280.dp,
    interactive: Boolean = true,
    onTap: () -> Unit = {}
) {
    val clock = rememberClock()
    var squish by remember { mutableStateOf(false) }
    val sq by animateFloatAsState(
        targetValue = if (squish) 0.8f else 1f,
        animationSpec = spring(dampingRatio = 0.35f, stiffness = 400f),
        label = "squish"
    )
    LaunchedEffect(squish) {
        if (squish) {
            delay(120)
            squish = false
        }
    }
    val tapMod = if (interactive) {
        Modifier.pointerInput(Unit) {
            detectTapGestures {
                squish = true
                onTap()
            }
        }
    } else {
        Modifier
    }

    Box(modifier.size(boxSize).then(tapMod), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val t = clock.t
            val w = this.size.width
            val r = w * 0.27f
            val cx = w / 2f
            var cy = w * 0.6f + sin(t * 2.4f) * w * 0.022f
            if (sky == Sky.NIGHT) cy = w * 0.62f + sin(t * 1.2f) * w * 0.012f
            if (mood == Mood.HAPPY) cy -= abs(sin(t * 10f)) * w * 0.03f
            val shake = if (sky == Sky.STORM) sin(t * 45f) * w * 0.006f else 0f
            val lean = if (sky == Sky.WINDY) 9f + sin(t * 3f) * 5f else 0f

            drawOval(Color(0x22000000), Offset(cx - r * 0.8f, w * 0.93f), Size(r * 1.6f, r * 0.25f))
            withTransform({
                translate(shake, 0f)
                rotate(lean, Offset(cx, w * 0.95f))
                scale(1f + (1f - sq) * 0.6f, sq, Offset(cx, w * 0.9f))
            }) {
                drawBuddy(cx, cy, r, sky, mood, t)
            }
        }
        if (sky == Sky.NIGHT) {
            val a by rememberInfiniteTransition(label = "z").animateFloat(
                initialValue = 0.2f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(tween(1400), RepeatMode.Reverse),
                label = "za"
            )
            Text(
                "z Z z",
                color = Color.White.copy(alpha = a),
                fontSize = (boxSize.value * 0.08f).sp,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = boxSize * 0.1f, end = boxSize * 0.1f)
            )
        }
    }
}

private fun DrawScope.drawBuddy(cx: Float, cy: Float, r: Float, sky: Sky, mood: Mood, t: Float) {
    // свечение
    val gc = Offset(cx, cy)
    drawCircle(
        Brush.radialGradient(listOf(Color(0x99FFD54F), Color(0x00FFD54F)), center = gc, radius = r * 1.9f),
        radius = r * 1.9f,
        center = gc
    )

    // ёлка рядом (Новый год)
    if (sky == Sky.NEWYEAR) drawTree(cx + r * 1.55f, cy + r * 0.95f, r * 1.1f, t)

    // тело: пять долек-облачков и центр
    val body = Brush.verticalGradient(
        listOf(Color(0xFF241A63), Color(0xFF4A2FB0), Color(0xFF7B5BE6)),
        startY = cy - r,
        endY = cy + r
    )
    val lobe = r * 0.42f
    val ring = r * 0.62f
    for (k in 0 until 5) {
        val a = Math.toRadians(270.0 + k * 72.0)
        drawCircle(body, lobe, Offset(cx + (cos(a) * ring).toFloat(), cy + (sin(a) * ring).toFloat()))
    }
    drawCircle(body, r * 0.78f, Offset(cx, cy))
    drawCircle(Color(0x22FFFFFF), r * 0.22f, Offset(cx - r * 0.42f, cy - r * 0.62f))

    // светящаяся звезда
    val sx = cx
    val sy = cy + r * 0.12f
    val pulse = 1f + 0.06f * sin(t * (if (mood == Mood.HAPPY) 9f else 3f))
    val sr = r * 0.46f * pulse * (if (mood == Mood.SAD) 0.8f else 1f)
    val rot = -PI.toFloat() / 2f + t * 0.3f
    drawPath(starPath(sx, sy, sr * 1.5f, sr * 1.0f, rot), Color(0x22FFB74D))
    drawPath(starPath(sx, sy, sr * 1.25f, sr * 0.8f, rot), Color(0x33FFB74D))
    drawPath(
        starPath(sx, sy, sr, sr * 0.62f, rot),
        Brush.radialGradient(
            listOf(Color(0xFFFFE08A), Color(0xFFFFA45B), Color(0xFFFF7FA0)),
            center = Offset(sx, sy),
            radius = sr
        )
    )

    // глаза
    val ey = cy - r * 0.3f
    val ex = r * 0.3f
    val s = r * 0.09f
    val sw = r * 0.07f
    val stroke = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
    val blink = (t % 4.2f) < 0.12f
    when {
        sky == Sky.CLEAR && mood != Mood.SAD -> {
            // солнечные очки
            val gw = r * 0.4f
            val gh = r * 0.26f
            drawRoundRect(Color(0xFF111111), Offset(cx - ex - gw / 2f, ey - gh / 2f), Size(gw, gh), CornerRadius(r * 0.08f))
            drawRoundRect(Color(0xFF111111), Offset(cx + ex - gw / 2f, ey - gh / 2f), Size(gw, gh), CornerRadius(r * 0.08f))
            drawLine(Color(0xFF111111), Offset(cx - ex + gw / 2f, ey), Offset(cx + ex - gw / 2f, ey), strokeWidth = sw * 0.7f)
            drawLine(Color(0x66FFFFFF), Offset(cx - ex - gw * 0.25f, ey - gh * 0.25f), Offset(cx - ex, ey - gh * 0.25f), strokeWidth = sw * 0.35f, cap = StrokeCap.Round)
            drawLine(Color(0x66FFFFFF), Offset(cx + ex - gw * 0.25f, ey - gh * 0.25f), Offset(cx + ex, ey - gh * 0.25f), strokeWidth = sw * 0.35f, cap = StrokeCap.Round)
        }
        sky == Sky.NIGHT -> {
            for (sgn in listOf(-1f, 1f)) {
                drawArc(
                    Color.White, 20f, 140f, false,
                    Offset(cx + sgn * ex - s, ey - s * 0.6f), Size(s * 2f, s * 1.4f),
                    style = stroke
                )
            }
        }
        sky == Sky.STORM || mood == Mood.SAD -> {
            val down = if (mood == Mood.SAD) r * 0.08f else r * 0.03f
            for (sgn in listOf(-1f, 1f)) {
                drawCircle(Color.White, r * 0.12f, Offset(cx + sgn * ex, ey))
                drawCircle(Color(0xFF1A1A2E), r * 0.06f, Offset(cx + sgn * ex, ey + down))
            }
        }
        blink && mood == Mood.IDLE -> {
            drawLine(Color.White, Offset(cx - ex - s, ey), Offset(cx - ex + s, ey), strokeWidth = sw, cap = StrokeCap.Round)
            drawLine(Color.White, Offset(cx + ex - s, ey), Offset(cx + ex + s, ey), strokeWidth = sw, cap = StrokeCap.Round)
        }
        else -> {
            val left = Path()
            left.moveTo(cx - ex - s, ey - s)
            left.lineTo(cx - ex + s, ey)
            left.lineTo(cx - ex - s, ey + s)
            drawPath(left, Color.White, style = stroke)
            val right = Path()
            right.moveTo(cx + ex + s, ey - s)
            right.lineTo(cx + ex - s, ey)
            right.lineTo(cx + ex + s, ey + s)
            drawPath(right, Color.White, style = stroke)
        }
    }

    // аксессуары
    val topY = cy - ring
    when (sky) {
        Sky.SNOW -> {
            drawArc(
                Color.White, 195f, 150f, true,
                Offset(cx - lobe * 1.15f, topY - lobe * 1.15f), Size(lobe * 2.3f, lobe * 2.3f)
            )
            drawCircle(Color.White, lobe * 0.28f, Offset(cx - lobe * 0.95f, topY - lobe * 0.1f))
            drawCircle(Color.White, lobe * 0.22f, Offset(cx + lobe * 0.9f, topY - lobe * 0.2f))
        }
        Sky.NEWYEAR -> {
            val hat = Path()
            hat.moveTo(cx - lobe * 1.0f, topY + lobe * 0.15f)
            hat.lineTo(cx + lobe * 0.3f, topY - lobe * 1.7f)
            hat.lineTo(cx + lobe * 1.0f, topY + lobe * 0.2f)
            hat.close()
            drawPath(hat, Color(0xFFE53935))
            drawRoundRect(Color.White, Offset(cx - lobe * 1.1f, topY - lobe * 0.1f), Size(lobe * 2.2f, lobe * 0.45f), CornerRadius(lobe * 0.2f))
            drawCircle(Color.White, lobe * 0.28f, Offset(cx + lobe * 0.35f, topY - lobe * 1.75f))
        }
        Sky.RAIN, Sky.STORM -> {
            val canopyY = cy - r * 1.25f
            drawLine(Color(0xFF424242), Offset(cx, canopyY), Offset(cx, cy - r * 0.8f), strokeWidth = r * 0.06f, cap = StrokeCap.Round)
            drawArc(
                if (sky == Sky.RAIN) Color(0xFFE53935) else Color(0xFF7E57C2),
                180f, 180f, true,
                Offset(cx - r * 1.15f, canopyY - r * 0.8f), Size(r * 2.3f, r * 1.6f)
            )
        }
        else -> {}
    }
}

private fun DrawScope.drawTree(bx: Float, by: Float, u: Float, t: Float) {
    drawRect(Color(0xFF6D4C41), Offset(bx - u * 0.12f, by - u * 0.25f), Size(u * 0.24f, u * 0.25f))
    val greens = listOf(Color(0xFF2E7D32), Color(0xFF388E3C), Color(0xFF43A047))
    for (i in 0 until 3) {
        val baseY = by - u * 0.2f - i * u * 0.5f
        val half = u * (0.7f - i * 0.18f)
        val tri = Path()
        tri.moveTo(bx, baseY - u * 0.75f)
        tri.lineTo(bx - half, baseY)
        tri.lineTo(bx + half, baseY)
        tri.close()
        drawPath(tri, greens[i])
    }
    val topY = by - u * 0.2f - 2f * u * 0.5f - u * 0.75f
    drawPath(starPath(bx, topY, u * 0.16f, u * 0.07f, -PI.toFloat() / 2f), Color(0xFFFFEB3B))
    val lights = listOf(
        Offset(-0.3f, -0.35f), Offset(0.25f, -0.2f), Offset(-0.15f, -0.8f),
        Offset(0.2f, -0.95f), Offset(-0.05f, -1.35f), Offset(0.35f, -0.55f)
    )
    val cols = listOf(Color(0xFFFF5252), Color(0xFFFFEB3B), Color(0xFF40C4FF))
    for ((i, o) in lights.withIndex()) {
        val on = sin(t * 4f + i * 1.7f) > -0.3f
        drawCircle(
            if (on) cols[i % 3] else Color(0x55FFFFFF),
            u * 0.05f,
            Offset(bx + o.x * u, by + o.y * u * 0.9f)
        )
    }
}
